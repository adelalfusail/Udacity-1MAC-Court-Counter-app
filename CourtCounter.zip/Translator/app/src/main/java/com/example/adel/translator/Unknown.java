package com.example.adel.translator;

import android.content.Intent;
import android.graphics.Color;
import android.os.Build;
import android.os.Handler;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Window;
import android.view.WindowManager;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.ImageView;
import android.widget.TextView;

public class Unknown extends AppCompatActivity {
    ImageView icon;
    TextView welcomeMessge;
    Animation fromTop , fromButtom ;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_unknown);
        if(Build.VERSION.SDK_INT>=Build.VERSION_CODES.LOLLIPOP){
            Window window = getWindow();
            window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
            window.setStatusBarColor(Color.parseColor("#131313"));
        }
        icon=findViewById(R.id.splashicon);
        welcomeMessge=findViewById(R.id.titel);

        fromTop= AnimationUtils.loadAnimation(this,R.anim.fromtop);
        fromButtom= AnimationUtils.loadAnimation(this,R.anim.frombottom);

        fromButtom.setDuration(2000);
        fromTop.setDuration(2000);

        icon.setAnimation(fromTop);
        welcomeMessge.setAnimation(fromButtom);

        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                Intent home= new Intent(Unknown.this , MainActivity.class);

                startActivity(home);

                finish();
            }
        },2*1000);
    }
}
