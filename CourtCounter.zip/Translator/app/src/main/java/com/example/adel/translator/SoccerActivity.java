package com.example.adel.translator;

import android.content.Intent;
import android.graphics.Color;
import android.os.Build;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;

import java.util.ArrayList;

public class SoccerActivity extends AppCompatActivity {

    ImageButton start;
    ListView rules;
    ImageView backButtton;
    ImageView background;
    TextView sportTitel;
    final ArrayList<Categories> categories = new ArrayList<Categories>();
    Intent intent;
     String title;
     CategoriesAdapter categoriesAdapter;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_soccer);

        start = findViewById(R.id.startButton);
        rules = findViewById(R.id.ruleList);
        backButtton = findViewById(R.id.back);
        background = findViewById(R.id.background);
         sportTitel = findViewById(R.id.sportTitle);

         title = getIntent().getStringExtra("titel");

         if(title.equals("soccer")){
             if(Build.VERSION.SDK_INT>=Build.VERSION_CODES.LOLLIPOP){
                 Window window = getWindow();
                 window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
                 window.setStatusBarColor(Color.parseColor("#4baa7c"));
             }

             sportTitel.setText("SOCCER");
             background.setBackgroundResource(R.color.purbleWhitens);
             categories.add(new Categories(getString(R.string.list_sport_timer),"Timer",R.drawable.choronomater_screenshot));
             categories.add(new Categories(getString(R.string.List_sport_image),"Add image for teams",R.drawable.image_name_screenshot));
             categories.add(new Categories(getString(R.string.list_soccer_addValue_events),"Add values",R.drawable.add_event_screenshot));
             categories.add(new Categories(getString(R.string.list_share_start_shot),"start , screenshot ,and share with your friends",R.drawable.share_sohot_start_screenshot));
         }

         if (title.equals("basketball")){
             if(Build.VERSION.SDK_INT>=Build.VERSION_CODES.LOLLIPOP){
                 Window window = getWindow();
                 window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
                 window.setStatusBarColor(Color.parseColor("#e68134"));
             }

             sportTitel.setText("BASKETBALL");
             background.setBackgroundResource(R.color.blackWithGray);
             categories.add(new Categories(getString(R.string.list_sport_timer),"Timer",R.drawable.choronomater_screenshot));
             categories.add(new Categories(getString(R.string.List_sport_image),"Add image for teams",R.drawable.image_name_screenshot));
             categories.add(new Categories(getString(R.string.list_basketball_addValue_events),"Add values",R.drawable.add_event_screenshot));
             categories.add(new Categories(getString(R.string.list_share_start_shot),"start , screenshot ,and share with your friends",R.drawable.share_sohot_start_screenshot));
         }

        categoriesAdapter = new CategoriesAdapter(this,categories);
        rules.setAdapter(categoriesAdapter);

        start.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if(title.equals("soccer")){
                    intent = new Intent(SoccerActivity.this,Soccer.class);
                }
                if (title.equals("basketball")){
                    intent = new Intent(SoccerActivity.this,BasketBall.class);
                }
                if(title.equals("unknown")){
                    intent = new Intent(SoccerActivity.this,Unknown.class);
                }
                startActivity(intent);
            }
        });
        backButtton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });

    }
}
