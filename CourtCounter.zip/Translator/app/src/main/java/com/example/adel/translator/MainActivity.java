package com.example.adel.translator;

import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.os.Build;
import android.support.v4.app.ActivityOptionsCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.CardView;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.google.api.translate.Language;
import com.google.api.translate.Translate;
import com.google.api.translate.TranslateV1;
import com.google.api.translate.TranslateV2;
import com.google.api.translate.TranslatorFrame;

public class MainActivity extends AppCompatActivity {

    CardView soccer;
    CardView basketBall;

    SharedPreferences sharedPreferences;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        if(Build.VERSION.SDK_INT>=Build.VERSION_CODES.LOLLIPOP){
            Window window = getWindow();
            window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
            window.setStatusBarColor(Color.parseColor("#131313"));
        }

        soccer = findViewById(R.id.soccer);
        basketBall = findViewById(R.id.basketball);


        soccer.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MainActivity.this,SoccerActivity.class);
                intent.putExtra("titel","soccer");
                ActivityOptionsCompat activityOptionsCompat=
                        ActivityOptionsCompat.makeSceneTransitionAnimation(MainActivity.this);
                startActivity(intent);
            }
        });

        basketBall.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MainActivity.this,SoccerActivity.class);
                intent.putExtra("titel","basketball");
                startActivity(intent);
            }
        });


    }

}
