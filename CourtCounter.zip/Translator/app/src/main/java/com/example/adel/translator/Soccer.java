package com.example.adel.translator;

import android.content.Intent;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.os.SystemClock;
import android.provider.MediaStore;
import android.support.annotation.RequiresApi;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Chronometer;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.ToggleButton;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Date;

public class Soccer extends AppCompatActivity {

    TextView teamA_value,teamB_value,teamA_addValue,teamB_addValue , EvantRecored;
    LinearLayout setTimerView,timerView;
    ImageButton  teamA_image ,teamB_image ,screenShotButton , shareButton ;
    EditText teamA_Name , teamB_Name ;
    Chronometer chronometer ;
    ToggleButton startButton ;
   // ListView EvantListView ;
    String   goal = "Goooal ⚽ For :" , eventRecoredText = "";
    ArrayList <String> events = new ArrayList<String>();

    int valueOfTeam_A = 0 , valueOfTeam_B = 0 ;
    boolean stautesOffToggleButton ;
    MediaPlayer whistleSound ;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_soccer_soccer);
        if(Build.VERSION.SDK_INT>=Build.VERSION_CODES.LOLLIPOP){
            Window window = getWindow();
            window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
            window.setStatusBarColor(Color.parseColor("#4baa7c"));
        }

        /**
         * get Text view from activity_soccer_soccer
         */
        teamA_value = findViewById(R.id.teamA_valueOfGoals);
        teamB_value = findViewById(R.id.teamB_valueOfGoals);
        teamA_addValue = findViewById(R.id.teamA_increaseValue);
        teamB_addValue = findViewById(R.id.teamB_increaseValue);

        /**
         * grt LinearLayout
         */

        timerView = findViewById(R.id.timerView);
        /**
         * get ImageButtons
         */
        shareButton = findViewById(R.id.shareButton);
        teamA_image = findViewById(R.id.teamA_Image);
        teamB_image = findViewById(R.id.teamB_Image);

        screenShotButton = findViewById(R.id.screenShotButton);
        /**
         * getToggleButton
         */
        startButton = findViewById(R.id.startButton);

        /**
         * get EditText
         */
        teamA_Name = findViewById(R.id.teamA_Name);
        teamB_Name = findViewById(R.id.teamB_Name);

        /**
         * get Chronometer
         */
        chronometer = findViewById(R.id.chrono);

        /**
         * finally get ListView
         */
        EvantRecored = findViewById(R.id.soccerListView);
        /**
         *
         */
        whistleSound = MediaPlayer.create(Soccer.this , R.raw.fischio_rigore);
        /**
         * first we need to let user enter the time of the game using setTimerEditText
         * than user will click setTimerButton yo conform the enter time and get the Text from setTimerEditText
         * than we need to setVisibility of setTimerView to gone and setVisibility of timerView to visible
         * now we need to listen start button when user click on it chronometer start
         */
        startButton.setOnClickListener(new View.OnClickListener() {
            @RequiresApi(api = Build.VERSION_CODES.N)
            @Override
            public void onClick(View view) {

             stautesOffToggleButton = startButton.isChecked();

                if (!isEmpty(teamA_Name) && !isEmpty(teamB_Name) ) {





                    chronometer.setBase(SystemClock.elapsedRealtime());
                    teamA_Name.setEnabled(false);
                    teamB_Name.setEnabled(false);


                    if (stautesOffToggleButton) {
                        startButton.setText("Stop");


                     chronometer.start();
                     whistleSound.start();

                 } else {
                     chronometer.stop();
                        startButton.setText("Start");

                 }
             }else {
                 if (isEmpty(teamA_Name)){
                     teamA_Name.setError("Set The Team Name");
                 }
                 if (isEmpty(teamB_Name)){
                     teamB_Name.setError("Set The Team Name");
                 }

             }
            }
        });
        teamA_addValue.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (! isEmpty(teamA_Name)&& ! isEmpty(teamB_Name)) {
                    String Name = teamA_Name.getText().toString();
                    valueOfTeam_A++;
                    teamA_value.setText("" + valueOfTeam_A);
                    eventRecoredText += goal + Name + "\n";
                    EvantRecored.setText(eventRecoredText);
                }  else {
                    if (isEmpty(teamA_Name)){
                    teamA_Name.setError("Set The Team Name");
                }
                if (isEmpty(teamB_Name)){
                    teamB_Name.setError("Set The Team Name");
                }

            }
            }
        });
        teamB_addValue.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (! isEmpty(teamA_Name)&& ! isEmpty(teamB_Name)) {
                    String Name = teamB_Name.getText().toString();
                    valueOfTeam_B++;
                    teamB_value.setText("" + valueOfTeam_B);
                    eventRecoredText += goal + Name + "\n";
                    EvantRecored.setText(eventRecoredText);
                } else {
                    if (isEmpty(teamA_Name)){
                        teamA_Name.setError("Set The Team Name");
                    }
                    if (isEmpty(teamB_Name)){
                        teamB_Name.setError("Set The Team Name");
                    }

                }
            }
        });
        /**
         *
         */
        teamA_image.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent pickImage = new Intent(Intent.ACTION_PICK);
                pickImage.setType("image/*");
                startActivityForResult(pickImage , 1);
            }
        });
        teamB_image.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent pickImage = new Intent(Intent.ACTION_PICK);
                pickImage.setType("image/*");
                startActivityForResult(pickImage , 2);
            }
        });
      /*  yellowCard.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                eventRecoredText += yellowCardText+"\n" ;
                EvantRecored.setText(eventRecoredText);
            }
        });
        redCard.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                eventRecoredText += redCardText+"\n" ;
                EvantRecored.setText(eventRecoredText);
            }
        });*/
        screenShotButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                takeScreenshot();
            }
        });
        /**
         *
         */
        chronometer.setOnChronometerTickListener(new Chronometer.OnChronometerTickListener() {
            @Override
            public void onChronometerTick(Chronometer chronometer) {

                long base = chronometer.getBase();
                long elapsedRealtime = SystemClock.elapsedRealtime();
                long time = base - elapsedRealtime;

              //  EvantRecored.setText(""+SystemClock.elapsedRealtime());

               // chronometer.setBase();

                // Toast.makeText(Soccer.this , "time"+base ,Toast.LENGTH_LONG).show();
            }
        });
        shareButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent shareIntent = new Intent(Intent.ACTION_SEND);
                shareIntent.setType("image/*");
                File ImageFile = new File(Environment.getExternalStorageDirectory().toString()+"/Soccer.jpg");
                Uri uri = Uri.fromFile(ImageFile);
                shareIntent.putExtra(Intent.EXTRA_TEXT,"Event Of The Match ;\n"+eventRecoredText);
                shareIntent.putExtra(Intent.EXTRA_STREAM,uri);
                startActivity(Intent.createChooser(shareIntent , "Share Image"));

            }
        });
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode == RESULT_OK) {
            try {

                final Uri imageUri = data.getData();
                File imageFile = new File(getRealPathFromURI(imageUri));

                final InputStream imageStream = getContentResolver().openInputStream(imageUri);
                final Bitmap selectedImage = BitmapFactory.decodeStream(imageStream);
                if (requestCode == 1){
                    teamA_image.setImageBitmap(selectedImage);
                }else {
                    teamB_image.setImageBitmap(selectedImage);
                }

            }catch (FileNotFoundException e) {
                e.printStackTrace();
                Toast.makeText(Soccer.this, "Something went wrong", Toast.LENGTH_LONG).show();
            }

        }else {
            Toast.makeText(Soccer.this, "You haven't picked Image", Toast.LENGTH_LONG).show();
        }

    }

    @Override
    protected void onStart() {
        super.onStart();
       // chronometer.stop();
    }

    private String getRealPathFromURI(Uri imageUri) {

        Cursor cursor = getContentResolver().query(imageUri, null, null, null, null);
        cursor.moveToFirst();
        int idx = cursor.getColumnIndex(MediaStore.Images.ImageColumns.DATA);
        return cursor.getString(idx);
    }
    private void takeScreenshot() {
        Date now = new Date();
        android.text.format.DateFormat.format("yyyy-MM-dd_hh:mm:ss", now);

        try {
            // image naming and path  to include sd card  appending name you choose for file
            String mPath = Environment.getExternalStorageDirectory().toString() + "/Soccer.jpg";

            // create bitmap screen capture
            View v1 = getWindow().getDecorView().getRootView();
            v1.setDrawingCacheEnabled(true);
            Bitmap bitmap = Bitmap.createBitmap(v1.getDrawingCache());
            v1.setDrawingCacheEnabled(false);

            File imageFile = new File(mPath);

            FileOutputStream outputStream = new FileOutputStream(imageFile);
            int quality = 100;
            bitmap.compress(Bitmap.CompressFormat.JPEG, quality, outputStream);
            outputStream.flush();
            outputStream.close();

           // openScreenshot(imageFile);
        } catch (Throwable e) {
            // Several error may come out with file handling or DOM
            Toast.makeText(Soccer.this, "Can't Take Screen", Toast.LENGTH_LONG).show();
            e.printStackTrace();
        }
    }
    private void openScreenshot(File imageFile) {
        Intent intent = new Intent();
        intent.setAction(Intent.ACTION_VIEW);
        Uri uri = Uri.fromFile(imageFile);
        intent.setDataAndType(uri, "image/*");
        startActivity(intent);
    }

    boolean isEmpty(EditText text){
        CharSequence str=text.getText().toString();
        return TextUtils.isEmpty(str);
    }

}
